package com.jsspda.sql.bank.wapi.repository;

import org.springframework.data.repository.CrudRepository;

import com.jsspda.sql.bank.wapi.model.BankAccount;

public interface BankRepo extends CrudRepository<BankAccount, Integer> {

}
