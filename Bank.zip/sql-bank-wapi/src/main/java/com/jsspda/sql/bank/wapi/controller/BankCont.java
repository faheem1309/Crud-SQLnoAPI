package com.jsspda.sql.bank.wapi.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jsspda.sql.bank.wapi.model.BankAccount;
import com.jsspda.sql.bank.wapi.repository.BankRepo;

@Controller
public class BankCont {
	
	@Autowired
	BankRepo bankrepo;
	
	 @RequestMapping("index")
	    public String index() {
	        return "index.jsp";
	    }

	    @RequestMapping("addAcc")
	    public String addAcc(BankAccount acc) {
	        bankrepo.save(acc);
	        return "index.jsp";
	    }

	    @RequestMapping("getAcc")
	    public ModelAndView getAcc(@RequestParam int aid) {
	        ModelAndView mv = new ModelAndView("display.jsp");
	        BankAccount acc = bankrepo.findById(aid).orElse(new BankAccount());
	        mv.addObject(acc);
	        return mv;
	    }

	    @RequestMapping("delAcc")
	    public ModelAndView delAcc(@RequestParam int aid) {
	        ModelAndView mv = new ModelAndView("delete.jsp");
	        BankAccount acc = bankrepo.findById(aid).orElse(new BankAccount());
	        bankrepo.deleteById(aid);
	        mv.addObject(acc);
	        return mv;
	    }

	    @RequestMapping("updAcc")
	    public ModelAndView updAcc(BankAccount acc) {
	        ModelAndView mv = new ModelAndView("update.jsp");
	        acc = bankrepo.findById(acc.getAid()).orElse(new BankAccount());
	        mv.addObject(acc);
	        return mv;
	    }
}