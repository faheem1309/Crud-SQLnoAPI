package com.jsspda.sql.bank.wapi.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class BankAccount {
	
	@Id
	private int aid;          
    private String bname;     
    private String ahname;   
    private double bal;
	public int getAid() {
		return aid;
	}
	public void setAid(int aid) {
		this.aid = aid;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getAhname() {
		return ahname;
	}
	public void setAhname(String ahname) {
		this.ahname = ahname;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	@Override
	public String toString() {
		return "BankAccount [aid=" + aid + ", bname=" + bname + ", ahname=" + ahname + ", bal=" + bal + "]";
	}
}