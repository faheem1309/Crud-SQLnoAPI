package com.jsspda.sql.bank.wapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqlBankWapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SqlBankWapiApplication.class, args);
	}

}
