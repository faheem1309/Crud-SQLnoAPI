package com.jsspda.sql.bank.wapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqlBankWapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
