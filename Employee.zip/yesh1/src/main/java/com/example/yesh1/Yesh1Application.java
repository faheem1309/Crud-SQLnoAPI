package com.example.yesh1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Yesh1Application {

	public static void main(String[] args) {
		SpringApplication.run(Yesh1Application.class, args);
	}

}
