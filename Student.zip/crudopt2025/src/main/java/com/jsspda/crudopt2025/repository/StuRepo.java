package com.jsspda.crudopt2025.repository;

import org.springframework.data.repository.CrudRepository;

import com.jsspda.crudopt2025.model.Student;

public interface StuRepo extends CrudRepository<Student, Integer>{

}
