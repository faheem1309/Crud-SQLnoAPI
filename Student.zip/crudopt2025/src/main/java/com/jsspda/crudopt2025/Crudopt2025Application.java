package com.jsspda.crudopt2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Crudopt2025Application {

	public static void main(String[] args) {
		SpringApplication.run(Crudopt2025Application.class, args);
		//System.out.println("Welcome to Spring Boot Application");
	}

}
